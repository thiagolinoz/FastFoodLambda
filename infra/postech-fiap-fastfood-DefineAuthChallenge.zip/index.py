def lambda_handler(event, context):
    # Se for a primeira chamada de auth, já definimos que está autenticado
    event['response']['challengeName'] = None
    event['response']['issueTokens'] = True
    event['response']['failAuthentication'] = False
  return event
