def lambda_handler(event, context):
    # Aceita direto
    event['response']['answerCorrect'] = True
    return event
