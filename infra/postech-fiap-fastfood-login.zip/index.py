import json
import boto3
import hmac
import hashlib
import base64

# Configurações do Cognito
USER_POOL_CLIENT_ID = "76k10febb0nlcqhchi01affm67"
USER_POOL_CLIENT_SECRET = "u1k9e19a13ftvdknr0110iei2q1uevsq24223vopi8diemrttq5"  # deixe vazio se não tiver secret

cognito = boto3.client("cognito-idp")

def get_secret_hash(username):
    if not USER_POOL_CLIENT_SECRET:
        return None
    message = username + USER_POOL_CLIENT_ID
    dig = hmac.new(
        str(USER_POOL_CLIENT_SECRET).encode("utf-8"),
        msg=message.encode("utf-8"),
        digestmod=hashlib.sha256
    ).digest()
    return base64.b64encode(dig).decode()

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        username = body.get("username")

        if not username:
            return {"statusCode": 400, "body": json.dumps({"error": "username required"})}

        auth_params = { "USERNAME": username }

        secret_hash = get_secret_hash(username)
        if secret_hash:
            auth_params["SECRET_HASH"] = secret_hash

        response = cognito.initiate_auth(
            ClientId=USER_POOL_CLIENT_ID,
            AuthFlow="CUSTOM_AUTH",
            AuthParameters=auth_params
        )

        access_token = response["AuthenticationResult"]["AccessToken"]

        return {
            "statusCode": 200,
            "body": json.dumps({"accessToken": access_token})
        }

    except cognito.exceptions.NotAuthorizedException:
        return {"statusCode": 401, "body": json.dumps({"error": "Invalid username"})}
    except cognito.exceptions.UserNotFoundException:
        return {"statusCode": 404, "body": json.dumps({"error": "User does not exist"})}
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
