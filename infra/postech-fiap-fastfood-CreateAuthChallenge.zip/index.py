def lambda_handler(event, context):
    # Não criamos nenhum challenge
    return event
